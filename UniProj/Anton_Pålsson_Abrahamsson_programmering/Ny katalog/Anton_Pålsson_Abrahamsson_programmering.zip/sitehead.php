<html>
 <head>
  <title>PHP index</title>
 </head>
 <body>
 <?php
    echo '<p>Go to footer for a surprise.</p>';
     
         ?>
 </body>
</html>