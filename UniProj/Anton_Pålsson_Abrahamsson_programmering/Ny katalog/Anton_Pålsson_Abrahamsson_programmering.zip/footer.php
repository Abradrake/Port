<html>
 <head>
  <title>footer</title>
 </head>
 <body>
 <?php
    echo '<p>Boo, I am a ghost!</p>';?>
     <?php echo "Du verkar använda " . $_SERVER['HTTP_USER_AGENT']; ?>
 </body>
</html>